let sonic, shadow, silver;        // characters
let rings, redStarRings, itemBox; // items
let bg1, bg2, bg3;                     // backgrounds

let currentBg;      
let currentChar;    
let currentItem;    

let backgrounds = [];
let characters  = [];
let items       = [];

function preload() {
  // Characters
  sonic  = loadImage("Sonic.png");
  shadow = loadImage("sr2ddd2dd63a36a.png");
  silver = loadImage("Silver.png");

  // Items
  redStarRings = loadImage("Red_Star_Ring_art_SCU.png");
  rings        = loadImage("SPrimeRing.png");
  itemBox      = loadImage("Itembox.png");

  // Backgrounds
  bg1 = loadImage("bg1.png");
  bg2 = loadImage("bg2.png");
  bg3 = loadImage("bg3.png")
}

function setup() {
  createCanvas(500, 600);
  imageMode(CENTER);

  // fill arrays AFTER assets are loaded
  backgrounds = [bg1, bg2, bg3];
  characters  = [sonic, shadow, silver];
  items       = [rings, redStarRings, itemBox];

  // I pick initial random selection
  pickRandoms();

  noLoop();
}

function draw() {
  //draw text ON TOP
  fill(255);              // white text
  stroke(0);              // black outline
  strokeWeight(4);        // outline thickness
  textAlign(CENTER, TOP); // center horizontally, start at top
  textSize(16);
  text("Arrow Keys", width / 2, 20); 

  //background
  image(currentBg, width / 2, height / 2, width, height);

  //character (centered)
  image(currentChar, width / 2, height / 2, width * 0.8, height * 0.8);

  //item
  image(currentItem, width / 2, height * 0.85, width * 0.25, width * 0.25);
}

function keyReleased() {
  if (keyCode === LEFT_ARROW)  currentItem = random(items);
  if (keyCode === UP_ARROW)    currentChar = random(characters);
  if (keyCode === RIGHT_ARROW) currentBg   = random(backgrounds);
  redraw();
}


function pickRandoms() {
  currentBg   = random(backgrounds);
  currentChar = random(characters);
  currentItem = random(items);
}
